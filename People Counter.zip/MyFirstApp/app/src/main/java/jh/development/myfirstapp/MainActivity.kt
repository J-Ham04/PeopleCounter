package jh.development.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Vibrator
import android.view.HapticFeedbackConstants
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvMyTextView = findViewById<TextView>(R.id.textView)

        val btnPlus = findViewById<Button>(R.id.plusButton)
        val btnMin = findViewById<Button>(R.id.minusButton)

        var timesClicked = 0

        btnPlus.setOnClickListener {
            timesClicked += 1

            tvMyTextView.text = timesClicked.toString()
            btnPlus.performHapticFeedback(HapticFeedbackConstants.CONFIRM, 1000)
        }
        btnMin.setOnClickListener {
            if (timesClicked > 0) {
                timesClicked -= 1

                tvMyTextView.text = timesClicked.toString()
                btnMin.performHapticFeedback(HapticFeedbackConstants.CONFIRM, 1000)
            }
        }
    }
}